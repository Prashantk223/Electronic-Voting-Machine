

typedf struct{

    uint32_t *stackptr;
    uint8_t priority;
    uint8_t state;
    uint32_t *taskptr;
}TCB_st;

TCB TCB