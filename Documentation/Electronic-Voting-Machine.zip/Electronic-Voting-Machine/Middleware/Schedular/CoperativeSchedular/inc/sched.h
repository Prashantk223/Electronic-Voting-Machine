#ifndef SCHED_H
#define SCHED_H
#include <stdint.h>



extern void scheduler_loop();

#endif // SCHED_H
