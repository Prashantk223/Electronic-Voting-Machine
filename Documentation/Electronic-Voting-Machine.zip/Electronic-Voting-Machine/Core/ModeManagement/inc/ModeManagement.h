#ifndef MODEMANAGEMENT_H
#define MODEMANAGEMENT_H

#define MODE_IDLE           0u
#define MODE_CONFIG_INIT    1u
#define MODE_CONFIG         2u
#define MODE_NORMAL         3u
#define MODE_SHUTDOWN       4u

#define CONFIG_STATE_UNINIT              0u
#define CONFIG_STATE_DISPLAY_VOTES       1u
#define CONFIG_STATE_NORMAL_MODE         2u
#define CONFIG_STATE_SHUTDOWN            3u
#define CONFIG_STATE_UART_CONNECT        4u
#define CONFIG_STATE_RESET_DATA          5u
#define CONFIG_STATE_MAIN_MENU           6u
#define CONFIG_STATE_UART_CONNECT_DCM        7u
#include <stdint.h>
#include <stdbool.h>
typedef struct
{
    uint8_t Mode;
    uint8_t ConfigSate;
}ModeManagement_St;

typedef enum
{
    DCM_IDLE,
    DCM_WAITING,
    DCM_PROCESS,
    DCM_OP_COMPLETE
}Dcm_state_en;

typedef enum
{
    DCM_NO_SERVICE,
    DCM_SESSION_CONTROL = 0x10,
    DCM_READ_RDID = 0x22,
    DCM_SECURITY_ACCESS = 0x27,
    CM_WRITE_DID = 0x2E,
    DCM_ROUTINE_CONTROL = 0x31,
    DCM_TESTER_PRESENT = 0x3E
}Dcm_service_en;

typedef struct 
{
    /* data */
    uint8_t Dcm_rxBuffer[1024];
    uint8_t Dcm_txBuffer[1024];
    bool rxReady;
    bool txReady;
    Dcm_state_en state;
    Dcm_service_en service;
}Dcm_Process_st;

extern ModeManagement_St ModeManagement;    
extern void ModeM_init();
extern void ModeM_ConfigMode_Ev_Callback(uint8_t);
extern void ModeM_ConfigMode();
extern void EventMngt_Main();
const uint32_t EVM_IDENTIFICATION_NUMBER = 0xA0A0A0A0;
#endif // MODEMANAGEMENT_H
