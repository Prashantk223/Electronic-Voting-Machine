#ifndef MODEMANAGEMENT_C
#define MODEMANAGEMENT_C
#include "ModeManagement.h"
#include "stm32f407xx_gpio_driver.h"
#include "EventManagement.h"
#include "lcd.h"
#include <string.h>
Dcm_Process_st Dcm_Process = {0};
void Dcm_Main(void);
ModeManagement_St ModeManagement = {
    .Mode = MODE_IDLE
};

void ModeM_init()
{
    //start config Mode if config pin is pressed
    if((uint8_t)0x1 == (uint8_t)EventMngt_ReadButton(Event_GPIO_Handle[SYSCONFIGPIN_INDEX].GPIO_Handle_Ev.pGPIOx,
    									Event_GPIO_Handle[SYSCONFIGPIN_INDEX].GPIO_Handle_Ev.GPIO_PinConfig.GPIO_PinNumber))
    {
        ModeManagement.Mode       = MODE_CONFIG_INIT;
    } 
    else
    {
         ModeManagement.Mode = MODE_NORMAL;
         LCD_Job_t msg = {
             .type = LCD_JOB_STATIC,
             .duration_ms = 3000,
         };
         strcpy(msg.message, "Normal mode Entered");
         lcd_enqueue_job(msg);
         lcd_display_clear();
     	 lcd_print_auto_wrap("Welcome Prashant");
    }   
    ModeManagement.ConfigSate = MODE_IDLE;
}

void ModeM_ConfigMode_Ev_Callback(uint8_t pinIndex)
{
    if(pinIndex == SYSCONFIGPIN_INDEX)
    {
        ModeManagement.Mode = MODE_CONFIG;
        /* LCD Message: 
        * Config Mode Entered */
        LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Config Mode Entered ");
        lcd_enqueue_job(msg);

        
        /* Press 1 to Display Votes */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Press 1 to Display Votes  ");
        lcd_enqueue_job(msg);

        /* Press 2 to Normal Mode */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Press 2 to Normal Mode ");
        lcd_enqueue_job(msg);

        /* Press 3 to Shutdown */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Press 3 to Shutdown ");
        lcd_enqueue_job(msg);

        /* Press 4 to Connect with UART */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Press 4 to Connect with UART ");
        lcd_enqueue_job(msg);

        /* Press 5 to Reset All Data */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
        };
        strcpy(msg.message, "Press 5 to Reset All Data  ");
        lcd_enqueue_job(msg);
    }
    else if(pinIndex == 1)
    {
        lcd_job_clear();
        ModeManagement.ConfigSate = CONFIG_STATE_DISPLAY_VOTES;
    }
    else if(pinIndex == 2)
    {
        lcd_job_clear();
        ModeManagement.ConfigSate = CONFIG_STATE_NORMAL_MODE;
    }
    else if(pinIndex == 3)
    {
        lcd_job_clear();
        ModeManagement.ConfigSate = CONFIG_STATE_SHUTDOWN;
    }
    else if(pinIndex == 4)
    {
        lcd_job_clear();
        ModeManagement.ConfigSate = CONFIG_STATE_UART_CONNECT;
    }
    else if(pinIndex == 5)
    {
        lcd_job_clear();
        ModeManagement.ConfigSate = CONFIG_STATE_RESET_DATA;
    }
}
void ModeM_ConfigMode_State_Ev_Callback(uint8_t ConsigSate)
{
    if(ConsigSate > CONFIG_STATE_RESET_DATA)
    {
        /* LCD Message: Input Error */
    }
    else
    {
        ModeManagement.ConfigSate = CONFIG_STATE_DISPLAY_VOTES;
    }
  
}
void ModeM_ConfigMode()
{
    switch(ModeManagement.ConfigSate)
    {
        case CONFIG_STATE_DISPLAY_VOTES:
        {
            ModeManagement.ConfigSate = CONFIG_STATE_DISPLAY_VOTES;
            /* LCD Message: Display All candidates Votes 
            *  LCD Message: Press 6 for Main Menu
            */
            for(int i =0; i < NUM_CANDIDATES; i++)
            {
                LCD_Job_t msg = {
                    .type = LCD_JOB_STATIC,
                    .duration_ms = 1000,
                };
                strcpy(msg.message, CandidateVoting_Status[i].CandName);
                strcat(msg.message, "-");
                strcat(msg.message, CandidateVoting_Status[i].votes);
                strcat(msg.message, "votes");
                lcd_enqueue_job(msg);
            }
            break;
        }
        case CONFIG_STATE_NORMAL_MODE:
        {
            /* LCD Message: Normal Mode */
            ModeManagement.ConfigSate = CONFIG_STATE_SHUTDOWN;
            break;
        }
        case CONFIG_STATE_SHUTDOWN:
        {
            /* LCD Message: Shutdown Mode */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
            };
            strcpy(msg.message, "Shutting down ");
            lcd_enqueue_job(msg);
            /* Shutdown code */

            break;
        }
        case CONFIG_STATE_UART_CONNECT:
        {
            /* LCD Message: UART Connect Mode */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
            };
            strcpy(msg.message, "UART Connect Mode");
            lcd_enqueue_job(msg);
            /* Connect with UART code*/
            ModeManagement.ConfigSate = CONFIG_STATE_UART_CONNECT_DCM;
            break;
        }
        case CONFIG_STATE_RESET_DATA:
        {
            /* Reset All permanently stored data */
            LCD_Job_t msg = {
            .type = LCD_JOB_STATIC,
            .duration_ms = 1000,
            };
            strcpy(msg.message, "Erase All data");
            lcd_enqueue_job(msg);
            break;
        }
        case CONFIG_STATE_UART_CONNECT_DCM:
        {
            Dcm_Process.state = DCM_WAITING;
            break;
        }
        default:
        {

        }
    }
}

void Dcm_Main(void)
{
    uint16_t RDID = 0;
    uint16_t ReqLength = (Dcm_Process.Dcm_rxBuffer[0] << 8) | Dcm_Process.Dcm_rxBuffer[1];
    uint16_t routine = 0;
    uint8_t tempbuffer[1024];
    switch(Dcm_Process.state)
    {
        case DCM_IDLE:
        break;
        case DCM_WAITING:
        if(Dcm_Process.rxReady == true)
        {
            Dcm_Process.state = DCM_PROCESS;
            Dcm_Process.service = (Dcm_service_en)Dcm_Process.Dcm_rxBuffer[2];
        }
        break;
        
        case DCM_PROCESS:
            switch(Dcm_Process.service)
            {
                case DCM_READ_RDID:
                if(ReqLength == 3)
                {
                    RDID = (Dcm_Process.Dcm_rxBuffer[3] << 8) | Dcm_Process.Dcm_rxBuffer[4];
                    if(RDID == 0xF190)
                    {
                        //EVM Identification  Number     EVM_IDENTIFICATION     
                        //	Active EVM state Session  
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x07; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x62;  
                        Dcm_Process.Dcm_txBuffer[3] = 0xF1; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x90;  
                        Dcm_Process.Dcm_txBuffer[5] = (uint8_t)((EVM_IDENTIFICATION_NUMBER  & 0xFF000000) >> 24);   
                        Dcm_Process.Dcm_txBuffer[6] = (uint8_t)((EVM_IDENTIFICATION_NUMBER  & 0x00FF0000) >> 16);   
                        Dcm_Process.Dcm_txBuffer[7] = (uint8_t)((EVM_IDENTIFICATION_NUMBER  & 0x0000FF00) >> 8);    
                        Dcm_Process.Dcm_txBuffer[8] = (uint8_t)((EVM_IDENTIFICATION_NUMBER  & 0xFF));                 
                    }
                    else if(RDID == 0xF111)
                    {
                        //	Active EVM state Session  
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x05; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x62;  
                        Dcm_Process.Dcm_txBuffer[3] = 0xF1; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x11;  
                        Dcm_Process.Dcm_txBuffer[5] = ModeManagement.Mode;   
                        Dcm_Process.Dcm_txBuffer[6] = ModeManagement.ConfigSate;                          
                    }
                    else
                    {
                        //NRC: Service Not Supported
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x03; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x7F;  
                        Dcm_Process.Dcm_txBuffer[3] = 0x22; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x11;  
                    }
                }
                break;
                case CM_WRITE_DID:
                    RDID = (Dcm_Process.Dcm_rxBuffer[3] << 8) | Dcm_Process.Dcm_rxBuffer[4];
                    //00 05 2E F1 90 03
                    if((RDID == 0xF111) && (Dcm_Process.Dcm_rxBuffer[5] == MODE_NORMAL))
                    {
                        //EVM Identification  Number     EVM_IDENTIFICATION     
                        //	Active EVM state Session  
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x03; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x6E;  
                        Dcm_Process.Dcm_txBuffer[3] = 0xF1; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x11;    
                        
                        ModeManagement.Mode = MODE_NORMAL;
                        ModeManagement.ConfigSate = CONFIG_STATE_UNINIT;
                    }
                    else if((RDID == 0xF111) && (Dcm_Process.Dcm_rxBuffer[5] == MODE_SHUTDOWN))
                    {
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x03; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x6E;  
                        Dcm_Process.Dcm_txBuffer[3] = 0xF1; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x11;    
                        
                        ModeManagement.Mode = MODE_SHUTDOWN;
                        ModeManagement.ConfigSate = CONFIG_STATE_UNINIT;
                    }
                    else
                    {
                        //NRC: Service Not Supported
                        Dcm_Process.Dcm_txBuffer[0] = 0x00;
                        Dcm_Process.Dcm_txBuffer[1] = 0x03; 
                        Dcm_Process.Dcm_txBuffer[2] = 0x7F;  
                        Dcm_Process.Dcm_txBuffer[3] = 0x22; 
                        Dcm_Process.Dcm_txBuffer[4] = 0x11;  
                    }
                break;
                case DCM_ROUTINE_CONTROL:
                    uint32_t index = 0;
                    uint8_t ascii_array[10];
                    uint32_t Cand_index = 0;
                    // 00 05 31 01 FF 00
                    routine = (Dcm_Process.Dcm_rxBuffer[4] << 8) | Dcm_Process.Dcm_rxBuffer[5] ;
                    Dcm_Process.Dcm_txBuffer[0] = 0x00;
                    Dcm_Process.Dcm_txBuffer[1] = 0x04; 
                    Dcm_Process.Dcm_txBuffer[2] = 0x71;  
                    Dcm_Process.Dcm_txBuffer[3] = 0x01; 
                    Dcm_Process.Dcm_txBuffer[4] = Dcm_Process.Dcm_rxBuffer[4];  
                    Dcm_Process.Dcm_txBuffer[5] = Dcm_Process.Dcm_rxBuffer[5];  
                     if(routine = 0xFF00)
                     {
                        //erase all data;
                        memset(CandidateVoting_Status, 0, sizeof(CandidateVoting_Status));
                        //set default values
                        memset(CandidateVoting_Status, CandidateVoting_Status_Default, sizeof(CandidateVoting_Status_t));
                     }
                     else if (0xFF01 == routine)
                     {
                        //00 05 31 01 FF 00 AA
                        if( Dcm_Process.Dcm_rxBuffer[5] == 0xAA)
                        {
                            //read votes of all candidates. Response structure - nameLength(1byte) + Name(100bytes) + votes(4bytes)
                            index = 6;
                            for(int i = 0; i < NUM_CANDIDATES; i++)
                            {
                                Dcm_Process.Dcm_txBuffer[index] = strlen(CandidateVoting_Status[i].CandName);
                                index++;
                                memcopy(&Dcm_Process.Dcm_txBuffer[index], CandidateVoting_Status[i].CandName, strlen(CandidateVoting_Status[i].CandName));
                                index += strlen(CandidateVoting_Status[i].CandName);
                                //convert number to ascii
                                sprintf(ascii_array, "%d", CandidateVoting_Status[i].votes);
                                memcopy(&Dcm_Process.Dcm_txBuffer[index], ascii_array, strlen(ascii_array));
                                index += strlen(ascii_array);
                            }
                            Dcm_Process.Dcm_txBuffer[1] += index; 
                        }
                        else if((Dcm_Process.Dcm_rxBuffer[5] <= NUM_CANDIDATES) && ( Dcm_Process.Dcm_rxBuffer[5] > 0))
                        {
                            // read vote of candidate only 1 candidate
                            index = 6;
                            uint32_t Cand_index = Dcm_Process.Dcm_rxBuffer[5] ;
                            Dcm_Process.Dcm_txBuffer[index] = strlen(CandidateVoting_Status[Cand_index].CandName);
                            index++;
                            memcopy(&Dcm_Process.Dcm_txBuffer[index], CandidateVoting_Status[Cand_index].CandName, strlen(CandidateVoting_Status[i].CandName));
                            index += strlen(CandidateVoting_Status[Cand_index].CandName);
                            //convert number to ascii
                            sprintf(ascii_array, "%d", CandidateVoting_Status[i].votes);
                            memcopy(&Dcm_Process.Dcm_txBuffer[index], ascii_array, strlen(ascii_array));
                            index += strlen(ascii_array);
                            Dcm_Process.Dcm_txBuffer[1] += index; 
                        }
                     }
                     else if (0xFF02 == routine)
                     {

                        //00 05 31 01 FF 00 AA
                        if( Dcm_Process.Dcm_rxBuffer[5] == 0xAA)
                        {
                            /* display votes on lcd for all candidates */
                            index = 0;
                            for(int i = 0; i < NUM_CANDIDATES; i++)
                            {
                                tempbuffer[index] = strlen(CandidateVoting_Status[i].CandName);
                                index++;
                                memcopy(&tempbuffer[index], CandidateVoting_Status[i].CandName, strlen(CandidateVoting_Status[i].CandName));
                                index += strlen(CandidateVoting_Status[i].CandName);

                                
                                memcopy(&tempbuffer[index], " : ", 3);
                                index += 3;

                                //convert number to ascii
                                sprintf(ascii_array, "%d", CandidateVoting_Status[i].votes);
                                memcopy(&tempbuffer[index], ascii_array, strlen(ascii_array));
                                index += strlen(ascii_array);
                                
                                lcd_job_clear();
                                LCD_Job_t msg = {
                                    .type = LCD_JOB_SCROLLING,
                                    .duration_ms = 300,
                                };
                                strcpy(msg.message, tempbuffer);
                                lcd_enqueue_job(msg);
                                lcd_display_clear();
                            }
                        }
                        else if((Dcm_Process.Dcm_rxBuffer[5] <= NUM_CANDIDATES) && ( Dcm_Process.Dcm_rxBuffer[5] > 0))
                        {
                            index = 0;
                            Cand_index =  Dcm_Process.Dcm_rxBuffer[5] ;
                            tempbuffer[index] = strlen(CandidateVoting_Status[Cand_index].CandName);
                            index++;
                            memcopy(&tempbuffer[index], CandidateVoting_Status[Cand_index].CandName, strlen(CandidateVoting_Status[Cand_index].CandName));
                            index += strlen(CandidateVoting_Status[Cand_index].CandName);
                            //convert number to ascii
                            sprintf(ascii_array, "%d", CandidateVoting_Status[Cand_index].votes);
                            memcopy(&tempbuffer[index], ascii_array, strlen(ascii_array));
                            index += strlen(ascii_array);

                            lcd_job_clear();
                            //queue the request
                            LCD_Job_t msg = {
                            .type = LCD_JOB_SCROLLING,
                            .duration_ms = 300,
                            };
                            strcpy(msg.message, tempbuffer);
                            lcd_enqueue_job(msg);
                            lcd_display_clear();
                        }
                     }
                     
                    else
                    {
                        //NRC: Service Not Supported
                        Dcm_Process.Dcm_rxBuffer[0] = 0x00;
                        Dcm_Process.Dcm_rxBuffer[1] = 0x03; 
                        Dcm_Process.Dcm_rxBuffer[2] = 0x7F;  
                        Dcm_Process.Dcm_rxBuffer[3] = 0x31; 
                        Dcm_Process.Dcm_rxBuffer[4] = 0x11;  
                    }
                break;
                case DCM_TESTER_PRESENT:
                    //send positive response
                    Dcm_Process.Dcm_rxBuffer[0] = 0x00;
                    Dcm_Process.Dcm_rxBuffer[1] = 0x02; 
                    Dcm_Process.Dcm_rxBuffer[2] = 0x7E; 
                    Dcm_Process.Dcm_rxBuffer[3] = 0x00; 
                break;
                default:
                break;
            }
        Dcm_Process.state = DCM_IDLE;
        Dcm_Process.txReady == true; // handle transmission in UART_Main()
        Dcm_Process.rxReady = false; // reset rxReady for next operation
        break;
        
        case DCM_OP_COMPLETE:
        break;
        
        default:
        break;
    }
    


}
#endif // MODEMANAGEMENT_C
