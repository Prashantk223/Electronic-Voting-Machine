#ifndef EVENTMANAGEMENT_CFG_C
#define EVENTMANAGEMENT_CFG_C

#include "EventManagement.h"
#include "stm32f407xx_gpio_driver.h"


CandidateVoting_Status_t CandidateVoting_Status_Default[NUM_CANDIDATES] = {
    {"Chai Yadav",  GPIOA,  GPIO_PIN_NO_0, 0xFF, 0x00},
    {"Pammi Aunty", GPIOC,  GPIO_PIN_NO_0, 0xFF, 0x00},
    {"Bunty Don",   GPIOC,  GPIO_PIN_NO_1, 0xFF, 0x00},
    {"Biryani Bhai",GPIOC,  GPIO_PIN_NO_2, 0xFF, 0x00},
    {"Babu Bhaiya", GPIOC,  GPIO_PIN_NO_3, 0xFF, 0x00}
};
CandidateVoting_Status_t CandidateVoting_Status[NUM_CANDIDATES];
Event_GPIO_Handle_t Event_GPIO_Handle[NUM_EVENT_PINS] = {
    /*GPIO pins*/
     {{GPIOA,  {GPIO_PIN_NO_0, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI0}, // Candidate 1 input
     {{GPIOC,  {GPIO_PIN_NO_0, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI1},// Candidate 2 input
     {{GPIOC,  {GPIO_PIN_NO_1, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI2}, // Candidate 3 input
     {{GPIOC,  {GPIO_PIN_NO_2, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI3}, // Candidate 4 input
     {{GPIOC,  {GPIO_PIN_NO_3, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI4}, // Candidate 5 input
     {{GPIOA,  {GPIO_PIN_NO_1, GPIO_MODE_IN, GPIO_SPEED_FAST, GPIO_PIN_PD, GPIO_OP_TYPE_PP, PIN_DUMMY_ALT_FUNCTION}}, IRQ_NO_EXTI9_5}, //SYSConfig input
};

#endif // EVENTMANAGEMENT_CFG_C
